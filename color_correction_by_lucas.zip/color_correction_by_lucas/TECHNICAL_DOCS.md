# Documentação Técnica - Color Correction by Lucas

## Arquitetura do Nó

### Estrutura de Arquivos
```
color_correction_by_lucas/
├── __init__.py                 # Registro do nó no ComfyUI
├── nodes/
│   └── color_correction.py     # Implementação principal do nó
├── web/
│   └── js/
│       └── color_correction.js # Interface visual personalizada
├── README.md                   # Documentação do usuário
├── LICENSE                     # Licença MIT
└── node_config.json           # Configurações do nó
```

### Implementação Python

O nó é implementado como uma classe Python que herda as convenções do ComfyUI:

#### Parâmetros de Entrada
- `image`: Tensor de imagem (formato ComfyUI)
- `hue`: Float (-180.0 a 180.0) - Ajuste de matiz
- `saturation`: Float (0.0 a 3.0) - Multiplicador de saturação
- `gamma`: Float (0.1 a 3.0) - Correção gamma
- `contrast`: Float (0.0 a 3.0) - Multiplicador de contraste
- `brightness`: Float (0.0 a 3.0) - Multiplicador de brilho

#### Processamento de Imagem

1. **Conversão de Tensor**: Converte o tensor PyTorch para array NumPy
2. **Processamento PIL**: Usa PIL para ajustes de brilho e contraste
3. **Conversão HSV**: Usa OpenCV para ajustes de matiz e saturação
4. **Correção Gamma**: Aplica correção gamma matemática
5. **Normalização**: Retorna valores no range [0,1] para ComfyUI

#### Algoritmos Utilizados

**Correção de Matiz (Hue):**
```python
hsv_image[:, :, 0] = (hsv_image[:, :, 0] + hue) % 180
```

**Correção de Saturação:**
```python
hsv_image[:, :, 1] = np.clip(hsv_image[:, :, 1] * saturation, 0, 255)
```

**Correção Gamma:**
```python
image_normalized = np.power(image_normalized, 1.0 / gamma)
```

### Interface Visual JavaScript

A interface personalizada adiciona:

- **Styling Customizado**: Cores e bordas personalizadas
- **Ícones Visuais**: Emojis para identificar cada parâmetro
- **Menu Contextual**: Opções de reset e informações
- **Tooltips**: Informações detalhadas sobre cada controle

#### Funcionalidades da Interface

1. **Reset All Values**: Restaura todos os valores padrão
2. **About Dialog**: Mostra informações detalhadas do nó
3. **Visual Feedback**: Sliders com gradientes coloridos
4. **Node Styling**: Aparência personalizada com bordas e sombras

### Dependências

- **PyTorch**: Para manipulação de tensores
- **NumPy**: Para operações matemáticas em arrays
- **PIL (Pillow)**: Para ajustes básicos de imagem
- **OpenCV**: Para conversões de espaço de cor HSV

### Performance

- **Processamento em Lote**: Suporta múltiplas imagens simultaneamente
- **Otimização de Memória**: Processa imagens individualmente em lotes
- **Conversões Eficientes**: Minimiza conversões desnecessárias entre formatos

### Compatibilidade

- **ComfyUI**: Versão 0.1.0 ou superior
- **Python**: 3.8 ou superior
- **Sistemas**: Windows, Linux, macOS

### Extensibilidade

O código foi estruturado para facilitar futuras extensões:

- Novos parâmetros podem ser adicionados facilmente
- Interface visual é modular e customizável
- Algoritmos de correção podem ser substituídos ou aprimorados

### Debugging

Para debug, o nó inclui:

- Validação de entrada robusta
- Tratamento de erros gracioso
- Logs informativos no console do ComfyUI
- Verificações de tipo e range para todos os parâmetros

