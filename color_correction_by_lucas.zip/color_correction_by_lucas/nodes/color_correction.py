import torch
import numpy as np
from PIL import Image, ImageEnhance
import cv2


class ColorCorrectionByLucas:
    """
    A ComfyUI node for color correction with HUE, Saturation, Brightness, Contrast, Gamma, Noise and Blur adjustments.
    Created by Lucas.
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "hue": (
                    "FLOAT",
                    {
                        "default": 0.0,
                        "min": -180.0,
                        "max": 180.0,
                        "step": 1.0,
                        "display": "slider",
                    },
                ),
                "saturation": (
                    "FLOAT",
                    {
                        "default": 1.0,
                        "min": 0.0,
                        "max": 3.0,
                        "step": 0.01,
                        "display": "slider",
                    },
                ),
                "brightness": (
                    "FLOAT",
                    {
                        "default": 1.0,
                        "min": 0.0,
                        "max": 3.0,
                        "step": 0.01,
                        "display": "slider",
                    },
                ),
                "contrast": (
                    "FLOAT",
                    {
                        "default": 1.0,
                        "min": 0.0,
                        "max": 3.0,
                        "step": 0.01,
                        "display": "slider",
                    },
                ),
                "gamma": (
                    "FLOAT",
                    {
                        "default": 1.0,
                        "min": 0.1,
                        "max": 3.0,
                        "step": 0.01,
                        "display": "slider",
                    },
                ),
                "noise": (
                    "FLOAT",
                    {
                        "default": 0.0,
                        "min": 0.0,
                        "max": 1.0,
                        "step": 0.01,
                        "display": "slider",
                    },
                ),
                "blur": (
                    "INT",
                    {
                        "default": 0,
                        "min": 0,
                        "max": 10,
                        "step": 1,
                        "display": "slider",
                    },
                ),
            }
        }
    
    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("corrected_image",)
    FUNCTION = "apply_color_correction"
    CATEGORY = "image/color"
    
    def apply_color_correction(self, image, hue, saturation, brightness, contrast, gamma, noise, blur):
        """
        Apply color correction, noise, and blur to the input image.
        
        Args:
            image: Input image tensor
            hue: Hue adjustment (-180 to 180)
            saturation: Saturation multiplier (0 to 3)
            brightness: Brightness multiplier (0 to 3)
            contrast: Contrast multiplier (0 to 3)
            gamma: Gamma correction (0.1 to 3)
            noise: Noise intensity (0 to 1)
            blur: Blur radius (0 to 10)
        
        Returns:
            Corrected image tensor
        """
        # Convert tensor to numpy array
        if len(image.shape) == 4:
            # Batch dimension exists
            batch_size = image.shape[0]
            corrected_images = []
            
            for i in range(batch_size):
                single_image = image[i].cpu().numpy()
                corrected_image = self._process_single_image(
                    single_image, hue, saturation, brightness, contrast, gamma, noise, blur
                )
                corrected_images.append(corrected_image)
            
            # Stack back to batch
            result = np.stack(corrected_images, axis=0)
        else:
            # Single image
            single_image = image.cpu().numpy()
            result = self._process_single_image(
                single_image, hue, saturation, brightness, contrast, gamma, noise, blur
            )
            result = np.expand_dims(result, axis=0)
        
        # Convert back to tensor
        return (torch.from_numpy(result).float(),)
    
    def _process_single_image(self, image, hue, saturation, brightness, contrast, gamma, noise, blur):
        """
        Process a single image with color corrections, noise, and blur.
        """
        # Ensure image is in the right format (H, W, C) and range [0, 1]
        if image.max() <= 1.0:
            image_uint8 = (image * 255).astype(np.uint8)
        else:
            image_uint8 = image.astype(np.uint8)
        
        # Convert to PIL Image for easier manipulation
        pil_image = Image.fromarray(image_uint8)
        
        # Apply brightness
        if brightness != 1.0:
            enhancer = ImageEnhance.Brightness(pil_image)
            pil_image = enhancer.enhance(brightness)
        
        # Apply contrast
        if contrast != 1.0:
            enhancer = ImageEnhance.Contrast(pil_image)
            pil_image = enhancer.enhance(contrast)
        
        # Convert to numpy for HSV operations and other filters
        image_array = np.array(pil_image)
        
        # Apply hue and saturation adjustments using HSV color space
        if hue != 0.0 or saturation != 1.0:
            # Convert RGB to HSV
            hsv_image = cv2.cvtColor(image_array, cv2.COLOR_RGB2HSV).astype(np.float32)
            
            # Adjust hue (H channel)
            if hue != 0.0:
                hsv_image[:, :, 0] = (hsv_image[:, :, 0] + hue) % 180
            
            # Adjust saturation (S channel)
            if saturation != 1.0:
                hsv_image[:, :, 1] = np.clip(hsv_image[:, :, 1] * saturation, 0, 255)
            
            # Convert back to RGB
            image_array = cv2.cvtColor(hsv_image.astype(np.uint8), cv2.COLOR_HSV2RGB)
        
        # Apply gamma correction
        if gamma != 1.0:
            # Normalize to [0, 1]
            image_normalized = image_array.astype(np.float32) / 255.0
            # Apply gamma correction
            image_normalized = np.power(image_normalized, 1.0 / gamma)
            # Convert back to [0, 255]
            image_array = (image_normalized * 255).astype(np.uint8)

        # Apply noise
        if noise > 0.0:
            noise_intensity = noise * 255  # Scale noise to 0-255
            noise_array = np.random.normal(0, noise_intensity, image_array.shape).astype(np.uint8)
            image_array = cv2.add(image_array, noise_array)
            image_array = np.clip(image_array, 0, 255)

        # Apply blur
        if blur > 0:
            image_array = cv2.GaussianBlur(image_array, (blur * 2 + 1, blur * 2 + 1), 0)
        
        # Convert back to [0, 1] range for ComfyUI
        result = image_array.astype(np.float32) / 255.0
        
        return result


# Node class mapping for ComfyUI
NODE_CLASS_MAPPINGS = {
    "ColorCorrectionByLucas": ColorCorrectionByLucas
}

# Display name mapping
NODE_DISPLAY_NAME_MAPPINGS = {
    "ColorCorrectionByLucas": "Color Correction by Lucas"
}

