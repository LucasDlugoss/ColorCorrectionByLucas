import { app } from "../../scripts/app.js";

// Register the custom node with enhanced UI
app.registerExtension({
    name: "ColorCorrectionByLucas",
    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name === "ColorCorrectionByLucas") {
            // Add custom styling and behavior to the node
            const onNodeCreated = nodeType.prototype.onNodeCreated;
            nodeType.prototype.onNodeCreated = function () {
                const r = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
                
                // Set node color scheme
                this.color = "#2a2a3e";
                this.bgcolor = "#1e1e2e";
                
                // Add title styling
                this.title = "🎨 Color Correction by Lucas";
                
                // Customize widget appearance
                if (this.widgets) {
                    this.widgets.forEach((widget, index) => {
                        // Add custom styling to sliders
                        if (widget.type === "slider" || widget.type === "number") {
                            // Add labels with emojis for better UX
                            switch (widget.name) {
                                case "hue":
                                    widget.label = "🌈 Hue";
                                    break;
                                case "saturation":
                                    widget.label = "💧 Saturation";
                                    break;
                                case "brightness":
                                    widget.label = "💡 Brightness";
                                    break;
                                case "contrast":
                                    widget.label = "🔆 Contrast";
                                    break;
                                case "gamma":
                                    widget.label = "⚡ Gamma";
                                    break;
                                case "noise":
                                    widget.label = "📺 Noise";
                                    break;
                                case "blur":
                                    widget.label = "🌫️ Blur";
                                    break;
                            }
                        }
                    });
                }
                
                // Add custom properties
                this.properties = this.properties || {};
                this.properties["Node version"] = "1.0.0";
                this.properties["Author"] = "Lucas";
                
                return r;
            };
            
            // Override the drawing function for custom appearance
            const onDrawForeground = nodeType.prototype.onDrawForeground;
            nodeType.prototype.onDrawForeground = function (ctx) {
                const r = onDrawForeground ? onDrawForeground.apply(this, arguments) : undefined;
                
                // Add a subtle border effect
                ctx.strokeStyle = "#4a4a6a";
                ctx.lineWidth = 2;
                ctx.strokeRect(0, 0, this.size[0], this.size[1]);
                
                // Add author signature in bottom right
                ctx.fillStyle = "#888";
                ctx.font = "10px Arial";
                ctx.textAlign = "right";
                ctx.fillText("by Lucas", this.size[0] - 5, this.size[1] - 5);
                
                return r;
            };
            
            // Add tooltip information
            const getExtraMenuOptions = nodeType.prototype.getExtraMenuOptions;
            nodeType.prototype.getExtraMenuOptions = function (_, options) {
                const r = getExtraMenuOptions ? getExtraMenuOptions.apply(this, arguments) : undefined;
                
                options.push({
                    content: "ℹ️ About Color Correction",
                    callback: () => {
                        alert(`Color Correction by Lucas v1.0.0

This node provides comprehensive color correction tools:

🌈 Hue: Shifts the color hue (-180° to +180°)
💧 Saturation: Adjusts color intensity (0 to 3x)
💡 Brightness: Controls overall image brightness (0 to 3x)
🔆 Contrast: Adjusts the difference between light and dark (0 to 3x)
⚡ Gamma: Controls mid-tone brightness (0.1 to 3.0)
📺 Noise: Adds random noise to the image (0 to 1)
🌫️ Blur: Applies Gaussian blur (0 to 10 pixels)

Created with ❤️ by Lucas`);
                    }
                });
                
                options.push({
                    content: "🔄 Reset All Values",
                    callback: () => {
                        if (this.widgets) {
                            this.widgets.forEach(widget => {
                                switch (widget.name) {
                                    case "hue":
                                    case "noise":
                                    case "blur":
                                        widget.value = 0.0;
                                        break;
                                    case "saturation":
                                    case "brightness":
                                    case "contrast":
                                    case "gamma":
                                        widget.value = 1.0;
                                        break;
                                }
                            });
                        }
                        this.setDirtyCanvas(true);
                    }
                });
                
                options.push({
                    content: "🎯 Preset: Enhance Colors",
                    callback: () => {
                        if (this.widgets) {
                            this.widgets.forEach(widget => {
                                switch (widget.name) {
                                    case "hue":
                                        widget.value = 0.0;
                                        break;
                                    case "saturation":
                                        widget.value = 1.3;
                                        break;
                                    case "brightness":
                                        widget.value = 1.1;
                                        break;
                                    case "contrast":
                                        widget.value = 1.2;
                                        break;
                                    case "gamma":
                                        widget.value = 0.9;
                                        break;
                                    case "noise":
                                        widget.value = 0.0;
                                        break;
                                    case "blur":
                                        widget.value = 0;
                                        break;
                                }
                            });
                        }
                        this.setDirtyCanvas(true);
                    }
                });
                
                options.push({
                    content: "🌙 Preset: Vintage Look",
                    callback: () => {
                        if (this.widgets) {
                            this.widgets.forEach(widget => {
                                switch (widget.name) {
                                    case "hue":
                                        widget.value = 10.0;
                                        break;
                                    case "saturation":
                                        widget.value = 0.8;
                                        break;
                                    case "brightness":
                                        widget.value = 0.9;
                                        break;
                                    case "contrast":
                                        widget.value = 1.1;
                                        break;
                                    case "gamma":
                                        widget.value = 1.2;
                                        break;
                                    case "noise":
                                        widget.value = 0.05;
                                        break;
                                    case "blur":
                                        widget.value = 1;
                                        break;
                                }
                            });
                        }
                        this.setDirtyCanvas(true);
                    }
                });
                
                return r;
            };
        }
    }
});

// Add custom CSS styles
const style = document.createElement('style');
style.textContent = `
    .comfy-node[data-title*="Color Correction by Lucas"] {
        border: 2px solid #4a4a6a !important;
        border-radius: 8px !important;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3) !important;
    }
    
    .comfy-node[data-title*="Color Correction by Lucas"] .comfy-widget {
        background: rgba(255, 255, 255, 0.05) !important;
        border-radius: 4px !important;
        margin: 2px 0 !important;
    }
    
    .comfy-node[data-title*="Color Correction by Lucas"] .comfy-widget input[type="range"] {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%) !important;
        border-radius: 10px !important;
        height: 6px !important;
    }
    
    .comfy-node[data-title*="Color Correction by Lucas"] .comfy-widget input[type="range"]::-webkit-slider-thumb {
        background: #fff !important;
        border: 2px solid #667eea !important;
        border-radius: 50% !important;
        width: 16px !important;
        height: 16px !important;
        cursor: pointer !important;
    }
    
    .comfy-node[data-title*="Color Correction by Lucas"] .comfy-widget input[type="range"]::-moz-range-thumb {
        background: #fff !important;
        border: 2px solid #667eea !important;
        border-radius: 50% !important;
        width: 16px !important;
        height: 16px !important;
        cursor: pointer !important;
    }
`;
document.head.appendChild(style);

